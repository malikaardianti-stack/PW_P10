
<?php
require_once __DIR__ . "/../config/auth.php";
require __DIR__ . "/../config/koneksi.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../pages/form_mahasiswa.php");
    exit;
}

$nama = trim($_POST["nama"] ?? "");
$nim = trim($_POST["nim"] ?? "");
$email = trim($_POST["email"] ?? "");
$prodi = trim($_POST["prodi"] ?? "");

if ($nama === "" || $nim === "" || $email === "" || $prodi === "") {
    die("Semua kolom wajib diisi.");
}

$stmt = $conn->prepare(
    "INSERT INTO mahasiswa (nama, nim, email, program_studi)
     VALUES (?, ?, ?, ?)"
);

if (!$stmt) {
    die("Query gagal: " . $conn->error);
}

$stmt->bind_param("ssss", $nama, $nim, $email, $prodi);

if ($stmt->execute()) {
    $stmt->close();
    $conn->close();

    header("Location: ../pages/data_mahasiswa.php?status=sukses");
    exit;
}

die("Gagal menyimpan data: " . $stmt->error);
?>
