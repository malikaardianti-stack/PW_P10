<?php
require __DIR__ . "/../config/koneksi.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../pages/data_mahasiswa.php");
    exit;
}

$nim = trim($_POST["nim"] ?? "");
$nama = trim($_POST["nama"] ?? "");
$program_studi = trim($_POST["program_studi"] ?? "");
$email = trim($_POST["email"] ?? "");

if ($nim === "" || $nama === "" ||
    $program_studi === "" || $email === "") {
    die("Semua kolom harus diisi.");
}

$stmt = $conn->prepare(
    "INSERT INTO mahasiswa (nim, nama, program_studi, email)
     VALUES (?, ?, ?, ?)"
);

$stmt->bind_param("ssss", $nim, $nama, $program_studi, $email);

if ($stmt->execute()) {
    header("Location: ../pages/data_mahasiswa.php?success=tambah");
    exit;
} else {
    die("Gagal menambahkan data: " . $stmt->error);
}
?>