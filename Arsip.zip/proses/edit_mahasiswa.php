<?php
require __DIR__ . "/../config/koneksi.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../pages/data_mahasiswa.php");
    exit;
}

$id = intval($_POST["id"] ?? 0);
$nim = trim($_POST["nim"] ?? "");
$nama = trim($_POST["nama"] ?? "");
$program_studi = trim($_POST["program_studi"] ?? "");
$email = trim($_POST["email"] ?? "");

if ($id <= 0 || $nim === "" || $nama === "" ||
    $program_studi === "" || $email === "") {
    die("Data tidak lengkap.");
}

$stmt = $conn->prepare(
    "UPDATE mahasiswa
     SET nim = ?, nama = ?, program_studi = ?, email = ?
     WHERE id = ?"
);

$stmt->bind_param("ssssi", $nim, $nama, $program_studi, $email, $id);

if ($stmt->execute()) {
    header("Location: ../pages/data_mahasiswa.php?success=edit");
    exit;
} else {
    die("Gagal mengedit data: " . $stmt->error);
}
?>