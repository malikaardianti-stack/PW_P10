<?php
// Buka halaman awal yang sekarang berada di folder pages.
header("Location: pages/index.php");
exit;
