
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION["user_id"])) {
    header("Location: dashboard.php");
    exit;
}

$judul = "Login";

include __DIR__ . "/../template/header.php";
?>

<main class="login-main">

    <section class="login-card">

        <div class="login-decoration">♡</div>

        <span class="login-kicker">WELCOME BACK!</span>

        <h2>Masuk ke Project Hub</h2>

        <p class="login-description">
            Senang bertemu kembali! Silakan masuk
            untuk melanjutkan aktivitasmu.
        </p>

        <?php if (isset($_GET["error"])) { ?>
            <p class="pesan-error">
                Username atau password salah.
            </p>
        <?php } ?>

        <?php if (isset($_GET["logout"])) { ?>
            <p class="pesan-sukses">
                Anda berhasil logout. Sampai jumpa lagi! ♡
            </p>
        <?php } ?>

        <form action="../proses/proses_login.php"
              method="POST"
              class="login-form">

            <div class="login-field">
                <label for="username">Username</label>
                <input
                    id="username"
                    name="username"
                    type="text"
                    placeholder="Masukkan username"
                    required
                >
            </div>

            <div class="login-field">
                <label for="password">Password</label>
                <input
                    id="password"
                    name="password"
                    type="password"
                    placeholder="Masukkan password"
                    required
                >
            </div>

            <button type="submit" class="login-submit">
                Login Sekarang ♡
            </button>

        </form>

        <div class="login-bottom">
            <span>✿</span>
            Made with love by Ardianti Malika Putri
        </div>

    </section>

</main>

<?php include __DIR__ . "/../template/footer.php"; ?>
```