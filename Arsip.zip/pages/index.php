<?php
require_once __DIR__ . "/../config/auth.php";

$judul = "Biodata Saya";
$copyright = "© 2026 - Ardianti Malika Putri";
$teks_footer = "Web Programming 1 · Made with ♡";

include __DIR__ . "/../template/header.php";
?>

<main class="biodata-page">

    <section class="bio-hero">
        <div class="bio-hero-text">
            <span class="bio-kicker">HELLO, NICE TO MEET YOU</span>
            <h2>Welcome to My Profile <span>♡</span></h2>
            <p>
                Perkenalkan, aku Ardianti Malika Putri, mahasiswa S1 Informatika
                yang sedang belajar dan mengembangkan kemampuan di bidang teknologi.
            </p>
            <a class="bio-button" href="#tentang">
                Kenali Saya <span>↓</span>
            </a>
        </div>

        <div class="bio-hero-photo-wrap">
            <div class="bio-photo-frame">
                <img src="../assets/images/foto.jpg" alt="Foto Ardianti Malika Putri">
            </div>
            <span class="bio-sparkle sparkle-one">✦</span>
            <span class="bio-sparkle sparkle-two">♡</span>
        </div>
    </section>

    <section id="biodata" class="bio-section">
        <div class="bio-section-heading">
            <span class="bio-kicker">GET TO KNOW ME</span>
            <h2>Data Pribadi</h2>
            <p>Informasi singkat tentang diri saya.</p>
        </div>

        <div class="bio-details">
            <div class="bio-detail">
                <span>Nama Lengkap</span>
                <strong>Ardianti Malika Putri</strong>
            </div>

            <div class="bio-detail">
                <span>NIM</span>
                <strong>2410512143</strong>
            </div>

            <div class="bio-detail">
                <span>Program Studi</span>
                <strong>S1 Informatika</strong>
            </div>

            <div class="bio-detail">
                <span>Fakultas</span>
                <strong>Fakultas Ilmu Komputer</strong>
            </div>

            <div class="bio-detail">
                <span>Email</span>
                <strong>ardianti.malika@email.com</strong>
            </div>

            <div class="bio-detail">
                <span>Tempat Lahir</span>
                <strong>Jakarta</strong>
            </div>
        </div>
    </section>

    <section id="tentang" class="bio-section about-section">
        <div class="bio-section-heading">
            <span class="bio-kicker">A LITTLE ABOUT ME</span>
            <h2>Tentang Saya</h2>
        </div>

        <p>
            Saya Ardianti Malika Putri, mahasiswa Informatika yang sedang belajar
            pemrograman web dengan HTML, CSS, PHP, dan MySQL. Saya senang mempelajari
            hal baru, mencoba berbagai ide, dan mengembangkan kemampuan diri.
        </p>
    </section>

    <div class="bio-info-grid">

        <section id="pendidikan" class="bio-section bio-small-card">
            <div class="bio-section-heading">
                <span class="bio-kicker">MY JOURNEY</span>
                <h2>♡ Pendidikan</h2>
            </div>

            <ol class="bio-list">
                <li>SD</li>
                <li>SMP</li>
                <li>SMA</li>
                <li>S1 Informatika</li>
            </ol>
        </section>

        <section id="hobi" class="bio-section bio-small-card">
            <div class="bio-section-heading">
                <span class="bio-kicker">THINGS I LOVE</span>
                <h2>♡ Hobi</h2>
            </div>

            <div class="bio-tags">
                <span>Badminton</span>
                <span>Mendengarkan Musik</span>
                <span>Coding</span>
                <span>Membaca</span>
                <span>Traveling</span>
            </div>
        </section>

        <section id="skill" class="bio-section bio-small-card">
            <div class="bio-section-heading">
                <span class="bio-kicker">WHAT I CAN DO</span>
                <h2>♡ Skill</h2>
            </div>

            <div class="bio-tags">
                <span>HTML</span>
                <span>Python</span>
                <span>Microsoft Office</span>
                <span>Public Speaking</span>
            </div>
        </section>

        <section id="sosial-media" class="bio-section bio-small-card">
            <div class="bio-section-heading">
                <span class="bio-kicker">LET'S CONNECT</span>
                <h2>♡ Social Media</h2>
            </div>

            <div class="bio-social-links">
                <a href="https://www.instagram.com/" target="_blank" rel="noopener">Instagram ↗</a>
                <a href="https://www.linkedin.com/" target="_blank" rel="noopener">LinkedIn ↗</a>
                <a href="https://github.com/" target="_blank" rel="noopener">GitHub ↗</a>
            </div>
        </section>

    </div>
</main>

<?php include __DIR__ . "/../template/footer.php"; ?>