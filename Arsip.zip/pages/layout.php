<?php require_once __DIR__ . "/../config/auth.php";
include __DIR__ . "/../template/header.php";

$judul = "Layout Lab";
$teks_footer = "Web Programming 1 - CSS Practice";

?>

<!-- Sidebar kiri. Untuk sidebar kanan ubah menjadi: <div class="page-layout right"> -->
<div class="page-layout">

    <nav class="side-nav">
        <a href="dashboard.php">Dashboard</a>
    <a href="index.php">Biodata</a>
        <a href="layout.php">Layout Lab</a>
        <a href="data_mahasiswa.php">Data Mahasiswa</a>
        <a href="form_mahasiswa.php">Tambah Mahasiswa</a>
    <a href="../proses/logout.php">Logout</a>
        <a href="#profile">Profile</a>
        <a href="#skills">Skills</a>
        <a href="#goal">Learning Goal</a>
    </nav>

    <main>
        <section id="profile" class="card">
            <h2>Profile Summary</h2>
            <p>Saya sedang mempelajari HTML dan CSS untuk membangun website yang terstruktur dan mudah dibaca.</p>
        </section>

        <section id="skills" class="card">
            <h2>Skills</h2>
            <ul>
                <li>HTML</li>
                <li>CSS Basic</li>
                <li>Problem Solving</li>
            </ul>
        </section>

        <section id="goal" class="card">
            <h2>Learning Goal</h2>
            <p>Mampu mengubah struktur HTML menjadi berbagai tampilan menggunakan CSS.</p>
        </section>
    </main>

</div>

<?php include __DIR__ . "/../template/footer.php"; ?>
