<?php
$judul = "Tambah Mahasiswa";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Mahasiswa</title>
</head>
<body>

<h2>Tambah Data Mahasiswa</h2>

<form action="../proses/tambah_mahasiswa.php" method="POST">

    <label>NIM</label><br>
    <input type="text" name="nim" required><br><br>

    <label>Nama</label><br>
    <input type="text" name="nama" required><br><br>

    <label>Program Studi</label><br>
    <input type="text" name="program_studi" required><br><br>

    <label>Email</label><br>
    <input type="email" name="email" required><br><br>

    <button type="submit">Simpan</button>
    <a href="data_mahasiswa.php">Kembali</a>

</form>

</body>
</html>