<?php
require_once __DIR__ . "/../config/auth.php";
include __DIR__ . "/../template/header.php";

$judul = "Dashboard";
$judul_header = "Project Hub";
$deskripsi = "Selamat datang, " . $_SESSION["nama_lengkap"];

?>

<nav>
    <a href="dashboard.php">Dashboard</a>
    <a href="index.php">Biodata</a>
    <a href="layout.php">Layout Lab</a>
    <a href="data_mahasiswa.php">Data Mahasiswa</a>
    <a href="form_mahasiswa.php">Tambah Mahasiswa</a>
    <a href="../proses/logout.php">Logout</a>
</nav>

<main>
    <section>
        <h2>Daftar Modul</h2>
        <ul>
            <li><a href="index.php">Home / Biodata</a> (Modul 1 dan 2)</li>
            <li><a href="layout.php">Layout Lab</a> (Modul 3A)</li>
            <li><a href="data_mahasiswa.php">Data Mahasiswa</a> (Modul 3B)</li>
            <li><a href="form_mahasiswa.php">Tambah Mahasiswa</a> (Modul 4B)</li>
        </ul>
    </section>
</main>

<?php include __DIR__ . "/../template/footer.php"; ?>
