<?php
require __DIR__ . "/../config/koneksi.php";

$id = intval($_GET["id"] ?? 0);

$stmt = $conn->prepare(
    "SELECT id, nim, nama, program_studi, email
     FROM mahasiswa
     WHERE id = ?"
);

$stmt->bind_param("i", $id);
$stmt->execute();

$data = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$data) {
    die("Data mahasiswa tidak ditemukan.");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Mahasiswa</title>
</head>
<body>

<h2>Edit Data Mahasiswa</h2>

<form action="../proses/update_mahasiswa.php" method="POST">

    <input type="hidden" name="id"
           value="<?= htmlspecialchars($data['id']) ?>">

    <label>NIM</label><br>
    <input type="text" name="nim"
           value="<?= htmlspecialchars($data['nim']) ?>" required><br><br>

    <label>Nama</label><br>
    <input type="text" name="nama"
           value="<?= htmlspecialchars($data['nama']) ?>" required><br><br>

    <label>Program Studi</label><br>
    <input type="text" name="program_studi"
           value="<?= htmlspecialchars($data['program_studi']) ?>" required><br><br>

    <label>Email</label><br>
    <input type="email" name="email"
           value="<?= htmlspecialchars($data['email']) ?>" required><br><br>

    <button type="submit">Update</button>
    <a href="data_mahasiswa.php">Kembali</a>

</form>

</body>
</html>