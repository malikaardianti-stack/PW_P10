```javascript
document.addEventListener("DOMContentLoaded", function () {

    // Preview Foto
    const inputFoto = document.getElementById("foto");
    const previewFoto = document.getElementById("preview-foto");

    if (inputFoto && previewFoto) {
        inputFoto.addEventListener("change", function () {
            const file = this.files[0];

            if (file) {
                previewFoto.src = URL.createObjectURL(file);
                previewFoto.style.display = "block";
            }
        });
    }

    // Preview Audio
    const inputAudio = document.getElementById("audio");
    const previewAudio = document.getElementById("preview-audio");

    if (inputAudio && previewAudio) {
        inputAudio.addEventListener("change", function () {
            const file = this.files[0];

            if (file) {
                previewAudio.src = URL.createObjectURL(file);
                previewAudio.style.display = "block";
            }
        });
    }

    // Preview Dokumen
    const inputDokumen = document.getElementById("dokumen");
    const previewDokumen = document.getElementById("preview-dokumen");

    if (inputDokumen && previewDokumen) {
        inputDokumen.addEventListener("change", function () {
            const file = this.files[0];

            if (file) {
                previewDokumen.textContent = "File dipilih: " + file.name;
                previewDokumen.style.display = "block";
            }
        });
    }

});
```
