<?php
require_once __DIR__ . "/../config/auth.php";
require_once __DIR__ . "/../config/koneksi.php";
require_once __DIR__ . "/../config/media_helper.php";

$judul = "Tambah Media";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = $_POST["id_mahasiswa"] ?? "";

    $foto = null;
    $audio = null;
    $dokumen = null;

    if ($id === "") {
        $error = "Silakan pilih mahasiswa terlebih dahulu.";
    } else {
        if (
            isset($_FILES["foto"]) &&
            $_FILES["foto"]["error"] !== UPLOAD_ERR_NO_FILE
        ) {
            $foto = uploadMedia(
                $_FILES["foto"],
                [
                    "image/jpeg" => "jpg",
                    "image/png" => "png",
                    "image/webp" => "webp"
                ],
                5 * 1024 * 1024,
                __DIR__ . "/../uploads/images",
                "foto"
            );
        }

        if (
            isset($_FILES["audio"]) &&
            $_FILES["audio"]["error"] !== UPLOAD_ERR_NO_FILE
        ) {
            $audio = uploadMedia(
                $_FILES["audio"],
                [
                    "audio/mpeg" => "mp3",
                    "audio/wav" => "wav",
                    "audio/ogg" => "ogg"
                ],
                10 * 1024 * 1024,
                __DIR__ . "/../uploads/audio",
                "audio"
            );
        }

        if (
            isset($_FILES["dokumen"]) &&
            $_FILES["dokumen"]["error"] !== UPLOAD_ERR_NO_FILE
        ) {
            $dokumen = uploadMedia(
                $_FILES["dokumen"],
                [
    "application/pdf" => "pdf",
    "application/msword" => "doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document" => "docx",
    "image/jpeg" => "jpg",
    "image/png" => "png",
    "image/webp" => "webp",
    "image/gif" => "gif"
],
                10 * 1024 * 1024,
                __DIR__ . "/../uploads/documents",
                "dokumen"
            );
        }

        $stmt = mysqli_prepare(
            $conn,
            "UPDATE mahasiswa SET foto = ?, audio = ?, dokumen = ? WHERE id = ?"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "sssi",
            $foto,
            $audio,
            $dokumen,
            $id
        );

        if (mysqli_stmt_execute($stmt)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Data media gagal disimpan.";
        }
    }
}

$mahasiswa = mysqli_query(
    $conn,
    "SELECT id, nama FROM mahasiswa ORDER BY nama ASC"
);

include __DIR__ . "/../template/header.php";
?>

<main class="container">
    <h2>Tambah Media</h2>

    <?php if ($error !== "") { ?>
        <p style="color: red;">
            <?= htmlspecialchars($error); ?>
        </p>
    <?php } ?>

    <form method="POST" enctype="multipart/form-data">

        <label>Mahasiswa</label>
        <select name="id_mahasiswa" required>
            <option value="">-- Pilih Mahasiswa --</option>

            <?php while ($data = mysqli_fetch_assoc($mahasiswa)) { ?>
                <option value="<?= $data["id"]; ?>">
                    <?= htmlspecialchars($data["nama"]); ?>
                </option>
            <?php } ?>
        </select>

        <br><br>

        <label>Foto</label>
        <input
            type="file"
            name="foto"
            id="foto"
            accept="image/jpeg,image/png,image/webp"
        >
        <div id="preview-foto"></div>

        <br>

        <label>Audio</label>
        <input
            type="file"
            name="audio"
            id="audio"
            accept="audio/*"
        >
        <div id="preview-audio"></div>

        <br>

        <label>Dokumen</label>
        <input
            type="file"
            name="dokumen"
            id="dokumen"
            accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.webp,.gif"
        >
        <div id="preview-dokumen"></div>

        <br><br>

        <button type="submit">Simpan</button>
        <a href="index.php">Batal</a>

    </form>
</main>

<script src="../assets/js/media.js"></script>

<?php include __DIR__ . "/../template/footer.php"; ?>