<?php
require_once __DIR__ . "/../config/auth.php";
require_once __DIR__ . "/../config/koneksi.php";
require_once __DIR__ . "/../config/media_helper.php";

$judul = "Edit Media";
$error = "";

$id = $_GET["id"] ?? "";

if ($id === "") {
    header("Location: index.php");
    exit;
}

$stmt = mysqli_prepare($conn, "SELECT * FROM mahasiswa WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    header("Location: index.php");
    exit;
}

$foto = $data["foto"];
$audio = $data["audio"];
$dokumen = $data["dokumen"];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $fotoBaru = $foto;
    $audioBaru = $audio;
    $dokumenBaru = $dokumen;

    if (!empty($_FILES["foto"]["name"])) {
        $hasil = uploadMedia(
            $_FILES["foto"],
            [
                "image/jpeg" => "jpg",
                "image/png" => "png",
                "image/webp" => "webp"
            ],
            5 * 1024 * 1024,
            __DIR__ . "/../uploads/images",
            "foto"
        );

        if ($hasil !== null) {
            $fotoBaru = $hasil;
        }
    }

    if (!empty($_FILES["audio"]["name"])) {
        $hasil = uploadMedia(
            $_FILES["audio"],
            [
                "audio/mpeg" => "mp3",
                "audio/wav" => "wav",
                "audio/ogg" => "ogg"
            ],
            10 * 1024 * 1024,
            __DIR__ . "/../uploads/audio",
            "audio"
        );

        if ($hasil !== null) {
            $audioBaru = $hasil;
        }
    }

    if (!empty($_FILES["dokumen"]["name"])) {
        $hasil = uploadMedia(
            $_FILES["dokumen"],
            [
    "application/pdf" => "pdf",
    "application/msword" => "doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document" => "docx",
    "image/jpeg" => "jpg",
    "image/png" => "png",
    "image/webp" => "webp",
    "image/gif" => "gif"
],
            10 * 1024 * 1024,
            __DIR__ . "/../uploads/documents",
            "dokumen"
        );

        if ($hasil !== null) {
            $dokumenBaru = $hasil;
        }
    }

    $stmt = mysqli_prepare(
        $conn,
        "UPDATE mahasiswa SET foto = ?, audio = ?, dokumen = ? WHERE id = ?"
    );

    mysqli_stmt_bind_param(
        $stmt,
        "sssi",
        $fotoBaru,
        $audioBaru,
        $dokumenBaru,
        $id
    );

    if (mysqli_stmt_execute($stmt)) {
        if ($fotoBaru !== $foto && $foto !== null) {
            hapusMediaJikaAda($foto, __DIR__ . "/../uploads/images");
        }

        if ($audioBaru !== $audio && $audio !== null) {
            hapusMediaJikaAda($audio, __DIR__ . "/../uploads/audio");
        }

        if ($dokumenBaru !== $dokumen && $dokumen !== null) {
            hapusMediaJikaAda($dokumen, __DIR__ . "/../uploads/documents");
        }

        header("Location: index.php");
        exit;
    } else {
        $error = "Media gagal diperbarui.";
    }
}

include __DIR__ . "/../template/header.php";
?>

<main class="container">
    <h2>Edit Media</h2>

    <p>
        Nama Mahasiswa:
        <strong><?= htmlspecialchars($data["nama"]); ?></strong>
    </p>

    <?php if ($error !== "") { ?>
        <p style="color: red;">
            <?= htmlspecialchars($error); ?>
        </p>
    <?php } ?>

    <form method="POST" enctype="multipart/form-data">

        <label>Ganti Foto</label>
        <input
            type="file"
            name="foto"
            id="foto"
            accept="image/jpeg,image/png,image/webp"
        >

        <?php if (!empty($foto)) { ?>
            <p>Foto saat ini:</p>
            <img
                src="../uploads/images/<?= htmlspecialchars($foto); ?>"
                width="100"
            >
        <?php } ?>

        <div id="preview-foto"></div>

        <br>

        <label>Ganti Audio</label>
        <input
            type="file"
            name="audio"
            id="audio"
            accept="audio/*"
        >

        <?php if (!empty($audio)) { ?>
            <p>Audio saat ini:</p>
            <audio controls>
                <source src="../uploads/audio/<?= htmlspecialchars($audio); ?>">
            </audio>
        <?php } ?>

        <div id="preview-audio"></div>

        <br>

        <label>Ganti Dokumen</label>
        <input
            type="file"
            name="dokumen"
            id="dokumen"
            accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.webp,.gif"
        >

        <?php if (!empty($dokumen)) { ?>
            <p>
                <a
                    href="../uploads/documents/<?= htmlspecialchars($dokumen); ?>"
                    target="_blank"
                >
                    Lihat dokumen saat ini
                </a>
            </p>
        <?php } ?>

        <div id="preview-dokumen"></div>

        <br><br>

        <button type="submit">Simpan Perubahan</button>
        <a href="index.php">Batal</a>

    </form>
</main>

<script src="../assets/js/media.js"></script>

<?php include __DIR__ . "/../template/footer.php"; ?>