<?php
require_once __DIR__ . "/../config/auth.php";
require_once __DIR__ . "/../config/koneksi.php";

$judul = "CRUD Media";

$query = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY id DESC");

include __DIR__ . "/../template/header.php";
?>

<main class="container">
    <h2>CRUD Media</h2>

    <p>Kelola foto, audio, dan dokumen mahasiswa.</p>

    <a href="tambah.php">+ Tambah Media</a>

    <table border="1" cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Foto</th>
                <th>Audio</th>
                <th>Dokumen</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php
            $no = 1;

            while ($data = mysqli_fetch_assoc($query)) {
            ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= htmlspecialchars($data["nama"]); ?></td>

                    <td>
                        <?php if (!empty($data["foto"])) { ?>
                            <img
                                src="../uploads/images/<?= htmlspecialchars($data["foto"]); ?>"
                                width="80"
                            >
                        <?php } else { ?>
                            Belum ada foto
                        <?php } ?>
                    </td>

                    <td>
                        <?php if (!empty($data["audio"])) { ?>
                            <audio controls>
                                <source
                                    src="../uploads/audio/<?= htmlspecialchars($data["audio"]); ?>"
                                >
                            </audio>
                        <?php } else { ?>
                            Belum ada audio
                        <?php } ?>
                    </td>

                    <td>
                        <?php if (!empty($data["dokumen"])) { ?>
                            <a
                                href="../uploads/documents/<?= htmlspecialchars($data["dokumen"]); ?>"
                                target="_blank"
                            >
                                Lihat Dokumen
                            </a>
                        <?php } else { ?>
                            Belum ada dokumen
                        <?php } ?>
                    </td>

                    <td>
                        <a href="edit.php?id=<?= $data["id"]; ?>">
                            Edit
                        </a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</main>

<?php include __DIR__ . "/../template/footer.php"; ?>